package com.example.client;

import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.app.Dialog;
import android.content.DialogInterface;
import android.util.Log;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FilenameFilter;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.net.InetAddress;
import java.net.Socket;
import android.widget.Toast;
import android.annotation.SuppressLint;
import android.view.KeyEvent;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

 
public class Client extends Activity{
	

	private  String serverIP="192.168.0.16";
	private String serverPortm;
	private  int serverPort = 7025;
	static int kill=0;
	Socket sock = null;
	Thread thread;
	File file;
	static String filena="testMovie.mp4";
    String extention;
    boolean chk = false;
    TextView FilePath, ipText, portText;
    static FileList _FileList;
	//경로지정 다이얼로그

	
    private AsyncTask<Integer, String, Integer> mProgressDlg;
	//---
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		FilePath = (TextView) findViewById(R.id.FilePath);
		ipText = (TextView) findViewById(R.id.IpText);
		portText = (TextView) findViewById(R.id.PortText);
		
		thread = new Thread(new ClientTest());
		thread.start();
		
		
		Button setButton = (Button) findViewById(R.id.SetButton);
		
		//설정버튼
		setButton.setOnClickListener(new View.OnClickListener(){
			public void onClick(View v) {
				serverIP = ipText.getText().toString();
				serverPortm = portText.getText().toString();
			}
		});
		
		  
		 _FileList = new FileList(this);
		
        _FileList.setOnPathChangedListener(new OnPathChangedListener() {
			public void onChanged(String path) {
				FilePath.setText(".."+path);
			}
		});
        
        _FileList.setOnFileSelected(new OnFileSelectedListener() {
			public void onSelected(String path, String fileName) {
				FilePath.setText(".."+path+fileName);
				filena = fileName; 
				chk = true;
				Log.i("filena", filena);
			}
		});
        
        LinearLayout layout=(LinearLayout)findViewById(R.id.LinearLayout01);
        layout.addView(_FileList);
        
        _FileList.setPath("/sdcard");
        _FileList.setFocusable(true);
        _FileList.setFocusableInTouchMode(true);
	}
	
	class ClientTest implements Runnable{

		@Override
		public void run() {
			// TODO Auto-generated method stub
				try{
			          while(true){
			        	  
			        	  if(chk){
			        		  serverPort = Integer.parseInt(serverPortm);
			        		  
			        		  sock = new Socket(serverIP, serverPort);
			        	  
				           try{
					            PrintWriter out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(sock.getOutputStream())), true);
					            file = new File(FilePath.getText()+"");
					            //Log.i("t1", FilePath.getText()+"");
					            out.flush();
				                out.println(file.getName());
				                out.flush();
				                        
				                DataInputStream dis = new DataInputStream(new FileInputStream(new File(FilePath.getText()+"")));
				                //Log.i("t2", ((TextView) findViewById(R.id.FilePath)).getText()+"");
				                DataOutputStream dos = new DataOutputStream(sock.getOutputStream());
				                
				                byte[] buf = new byte[1024];
				                dos.flush();
				                int length_size =0 ;
				                while((length_size = dis.read(buf))>0)
				                {
				                   dos.write(buf,0,length_size);
				                   dos.flush();
				                }
				                dos.close();
				                chk = false;

				               
				           }
				           catch(Exception e){
				               e.printStackTrace();
				           }
				           finally
				           {
				              sock.close();
				           }
			          }
				}
			}
			catch(Exception e){
			             e.printStackTrace();
			}
		}

	}
	
	public void _finish(){
    	moveTaskToBack(true);
    	finish();
    	android.os.Process.killProcess(android.os.Process.myPid());
	}
	
	@Override
    public boolean onKeyDown(int keyCode, KeyEvent event)  { // 뒤로가기 키를 눌렀을때
        if (keyCode == KeyEvent.KEYCODE_BACK && event.getRepeatCount() == 0){
        	if(kill==0){
        		kill++;
        		Toast.makeText(this, "종료하시려면 한 번 더 누르세요", Toast.LENGTH_SHORT).show();
        	}else
        		_finish();
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
	
}
