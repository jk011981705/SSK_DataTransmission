import java.util.GregorianCalendar;

public class Today extends Server{

	// ���� ��¥
	public Today() {

		GregorianCalendar calender = new GregorianCalendar();
		int year, month, date, amPm, hour, min, sec;

		year = calender.get(calender.YEAR);
		month = calender.get(calender.MONTH);
		date = calender.get(calender.DATE);
		amPm = calender.get(calender.AM_PM);
		hour = calender.get(calender.HOUR);
		min = calender.get(calender.MINUTE);
		sec = calender.get(calender.SECOND);
		String sAmPm = amPm == calender.AM ? "����" : "����";
		String dd = year + "�� " + month + "�� " + date + "��  " + sAmPm + " "
				+ hour + "�� " + min + "�� " + sec + "��";
		log.append(dd + "\n");
	}
    
    public static void main(String[] args) {
    	new Today();
    }
}